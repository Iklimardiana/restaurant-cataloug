import 'regenerator-runtime';
import '../styles/main.scss';
import '../scripts/components/footer.js';
// import '../scripts/components/skipcontent.js';
import main from './view/main.js';


main();
